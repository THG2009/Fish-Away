// Made with Blockbench 4.8.3
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelhat_50<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "hat_50"), "main");
	private final ModelPart text_50;
	private final ModelPart bone;

	public Modelhat_50(ModelPart root) {
		this.text_50 = root.getChild("text_50");
		this.bone = root.getChild("bone");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition text_50 = partdefinition.addOrReplaceChild("text_50", CubeListBuilder.create(),
				PartPose.offset(-9.15F, 12.0F, 6.0F));

		PartDefinition character_5 = text_50.addOrReplaceChild("character_5",
				CubeListBuilder.create().texOffs(24, 18)
						.addBox(4.0F, 4.0F, -8.0F, 4.25F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(4, 18)
						.addBox(4.0F, 1.0F, -8.0F, 4.25F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(26, 5)
						.addBox(4.0F, -2.0F, -8.0F, 5.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(24, 22)
						.addBox(7.0F, 3.0F, -8.0F, 1.25F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(25, 26)
						.addBox(4.0F, 0.0F, -8.0F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(12, 28).mirror()
						.addBox(8.25F, 1.5F, -8.0F, 0.75F, 4.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition character_0 = text_50.addOrReplaceChild("character_0",
				CubeListBuilder.create().texOffs(14, 26)
						.addBox(9.3F, -2.0F, -8.0F, 2.0F, 8.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(12, 22)
						.mirror().addBox(11.3F, -2.0F, -8.0F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false)
						.texOffs(0, 7).addBox(12.3F, -2.0F, -8.0F, 2.0F, 8.0F, 4.0F, new CubeDeformation(0.0F))
						.texOffs(28, 28).addBox(11.3F, 4.0F, -8.0F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition bone = partdefinition.addOrReplaceChild("bone",
				CubeListBuilder.create().texOffs(8, 0).mirror()
						.addBox(-15.0F, -6.0F, 4.0F, 14.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false)
						.texOffs(8, 23).addBox(-1.0F, -6.0F, 4.0F, 1.0F, 3.0F, 8.0F, new CubeDeformation(0.0F))
						.texOffs(18, 23).addBox(-16.0F, -6.0F, 4.0F, 1.0F, 3.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offset(8.0F, 24.0F, -8.0F));

		return LayerDefinition.create(meshdefinition, 32, 32);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		text_50.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
		this.text_50.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.text_50.xRot = headPitch / (180F / (float) Math.PI);
		this.bone.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.bone.xRot = headPitch / (180F / (float) Math.PI);
	}
}