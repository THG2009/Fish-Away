
package net.mcreator.fishawayforge.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.fishawayforge.procedures.NetheriteFishingRodToolInHandTickProcedure;

import java.util.List;

public class NetheriteFishingRodItem extends FishingRodItem {
	public NetheriteFishingRodItem() {
		super(new Item.Properties().durability(400).fireResistant());
	}

	@Override
	public boolean isValidRepairItem(ItemStack itemstack, ItemStack repairitem) {
		return Ingredient.of(new ItemStack(Items.NETHERITE_SCRAP)).test(repairitem);
	}

	@Override
	public int getEnchantmentValue() {
		return 2;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		if (selected)
			NetheriteFishingRodToolInHandTickProcedure.execute(entity);
	}
}
