package net.mcreator.fishawayforge.procedures;

import net.minecraft.world.level.LevelAccessor;

public class BasicPowerCableForgeEnergySidesProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z) {
		double sides = 0;
		boolean east = false;
		boolean south = false;
		boolean north = false;
		boolean west = false;
		boolean up = false;
		boolean down = false;
		south = BasicPowerCableForgeEnergySouthProcedure.execute(world, x, y, z);
		north = BasicPowerCableForgeEnergyNorthProcedure.execute(world, x, y, z);
		east = BasicPowerCableForgeEnergyEastProcedure.execute(world, x, y, z);
		west = BasicPowerCableForgeEnergyWestProcedure.execute(world, x, y, z);
		up = BasicPowerCableForgeEnergyUpProcedure.execute(world, x, y, z);
		down = BasicPowerCableForgeEnergyDownProcedure.execute(world, x, y, z);
		sides = 0;
		if (south) {
			sides = sides + 1;
		}
		if (north) {
			sides = sides + 1;
		}
		if (east) {
			sides = sides + 1;
		}
		if (west) {
			sides = sides + 1;
		}
		if (up) {
			sides = sides + 1;
		}
		if (down) {
			sides = sides + 1;
		}
		return sides;
	}
}
