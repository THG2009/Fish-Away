
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishawayforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.fishawayforge.block.entity.BasicPowerCableXCBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableXBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableTXCCBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableTXCBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableTXBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableTCBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableTBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableSBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableLTCBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableLTBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableLCCBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableLCBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableLBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableIBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableFBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableEBlockEntity;
import net.mcreator.fishawayforge.block.entity.BasicPowerCableBlockEntity;
import net.mcreator.fishawayforge.FishAwayForgeMod;

public class FishAwayForgeModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, FishAwayForgeMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE = register("basic_power_cable", FishAwayForgeModBlocks.BASIC_POWER_CABLE, BasicPowerCableBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_E = register("basic_power_cable_e", FishAwayForgeModBlocks.BASIC_POWER_CABLE_E, BasicPowerCableEBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_F = register("basic_power_cable_f", FishAwayForgeModBlocks.BASIC_POWER_CABLE_F, BasicPowerCableFBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_I = register("basic_power_cable_i", FishAwayForgeModBlocks.BASIC_POWER_CABLE_I, BasicPowerCableIBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_L = register("basic_power_cable_l", FishAwayForgeModBlocks.BASIC_POWER_CABLE_L, BasicPowerCableLBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_LC = register("basic_power_cable_lc", FishAwayForgeModBlocks.BASIC_POWER_CABLE_LC, BasicPowerCableLCBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_LCC = register("basic_power_cable_lcc", FishAwayForgeModBlocks.BASIC_POWER_CABLE_LCC, BasicPowerCableLCCBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_LT = register("basic_power_cable_lt", FishAwayForgeModBlocks.BASIC_POWER_CABLE_LT, BasicPowerCableLTBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_LTC = register("basic_power_cable_ltc", FishAwayForgeModBlocks.BASIC_POWER_CABLE_LTC, BasicPowerCableLTCBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_T = register("basic_power_cable_t", FishAwayForgeModBlocks.BASIC_POWER_CABLE_T, BasicPowerCableTBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_TC = register("basic_power_cable_tc", FishAwayForgeModBlocks.BASIC_POWER_CABLE_TC, BasicPowerCableTCBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_TX = register("basic_power_cable_tx", FishAwayForgeModBlocks.BASIC_POWER_CABLE_TX, BasicPowerCableTXBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_TXC = register("basic_power_cable_txc", FishAwayForgeModBlocks.BASIC_POWER_CABLE_TXC, BasicPowerCableTXCBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_TXCC = register("basic_power_cable_txcc", FishAwayForgeModBlocks.BASIC_POWER_CABLE_TXCC, BasicPowerCableTXCCBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_X = register("basic_power_cable_x", FishAwayForgeModBlocks.BASIC_POWER_CABLE_X, BasicPowerCableXBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_XC = register("basic_power_cable_xc", FishAwayForgeModBlocks.BASIC_POWER_CABLE_XC, BasicPowerCableXCBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> BASIC_POWER_CABLE_S = register("basic_power_cable_s", FishAwayForgeModBlocks.BASIC_POWER_CABLE_S, BasicPowerCableSBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
