
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishawayforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.fishawayforge.block.EmeraldChunkStoneBlock;
import net.mcreator.fishawayforge.block.EmeraldChunkDeepslateBlock;
import net.mcreator.fishawayforge.block.DriftwoodLeavesBlock;
import net.mcreator.fishawayforge.block.DriftwoodBlockBlock;
import net.mcreator.fishawayforge.block.DiamondChunkStoneBlock;
import net.mcreator.fishawayforge.block.DiamondChunkDeepslateBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableXCBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableXBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableTXCCBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableTXCBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableTXBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableTCBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableTBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableSBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableLTCBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableLTBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableLCCBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableLCBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableLBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableIBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableFBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableEBlock;
import net.mcreator.fishawayforge.block.BasicPowerCableBlock;
import net.mcreator.fishawayforge.FishAwayForgeMod;

public class FishAwayForgeModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FishAwayForgeMod.MODID);
	public static final RegistryObject<Block> DRIFTWOOD_BLOCK = REGISTRY.register("driftwood_block", () -> new DriftwoodBlockBlock());
	public static final RegistryObject<Block> DRIFTWOOD_LEAVES = REGISTRY.register("driftwood_leaves", () -> new DriftwoodLeavesBlock());
	public static final RegistryObject<Block> DIAMOND_CHUNK_STONE = REGISTRY.register("diamond_chunk_stone", () -> new DiamondChunkStoneBlock());
	public static final RegistryObject<Block> EMERALD_CHUNK_STONE = REGISTRY.register("emerald_chunk_stone", () -> new EmeraldChunkStoneBlock());
	public static final RegistryObject<Block> DIAMOND_CHUNK_DEEPSLATE = REGISTRY.register("diamond_chunk_deepslate", () -> new DiamondChunkDeepslateBlock());
	public static final RegistryObject<Block> EMERALD_CHUNK_DEEPSLATE = REGISTRY.register("emerald_chunk_deepslate", () -> new EmeraldChunkDeepslateBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE = REGISTRY.register("basic_power_cable", () -> new BasicPowerCableBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_E = REGISTRY.register("basic_power_cable_e", () -> new BasicPowerCableEBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_F = REGISTRY.register("basic_power_cable_f", () -> new BasicPowerCableFBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_I = REGISTRY.register("basic_power_cable_i", () -> new BasicPowerCableIBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_L = REGISTRY.register("basic_power_cable_l", () -> new BasicPowerCableLBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_LC = REGISTRY.register("basic_power_cable_lc", () -> new BasicPowerCableLCBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_LCC = REGISTRY.register("basic_power_cable_lcc", () -> new BasicPowerCableLCCBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_LT = REGISTRY.register("basic_power_cable_lt", () -> new BasicPowerCableLTBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_LTC = REGISTRY.register("basic_power_cable_ltc", () -> new BasicPowerCableLTCBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_T = REGISTRY.register("basic_power_cable_t", () -> new BasicPowerCableTBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_TC = REGISTRY.register("basic_power_cable_tc", () -> new BasicPowerCableTCBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_TX = REGISTRY.register("basic_power_cable_tx", () -> new BasicPowerCableTXBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_TXC = REGISTRY.register("basic_power_cable_txc", () -> new BasicPowerCableTXCBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_TXCC = REGISTRY.register("basic_power_cable_txcc", () -> new BasicPowerCableTXCCBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_X = REGISTRY.register("basic_power_cable_x", () -> new BasicPowerCableXBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_XC = REGISTRY.register("basic_power_cable_xc", () -> new BasicPowerCableXCBlock());
	public static final RegistryObject<Block> BASIC_POWER_CABLE_S = REGISTRY.register("basic_power_cable_s", () -> new BasicPowerCableSBlock());
}
