
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishawayforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.fishawayforge.item.PearItem;
import net.mcreator.fishawayforge.item.OldBoot1Item;
import net.mcreator.fishawayforge.item.NetheriteFishingRodItem;
import net.mcreator.fishawayforge.item.IronFishingRodItem;
import net.mcreator.fishawayforge.item.Hat50Item;
import net.mcreator.fishawayforge.item.Hat100Item;
import net.mcreator.fishawayforge.item.GoldenFishingRodItem;
import net.mcreator.fishawayforge.item.DriftwoodScrapsItem;
import net.mcreator.fishawayforge.item.DiamondFishingRodItem;
import net.mcreator.fishawayforge.item.CopperSwordItem;
import net.mcreator.fishawayforge.item.CopperShovelItem;
import net.mcreator.fishawayforge.item.CopperPickaxeItem;
import net.mcreator.fishawayforge.item.CopperHoeItem;
import net.mcreator.fishawayforge.item.CopperFishingRodItem;
import net.mcreator.fishawayforge.item.CopperAxeItem;
import net.mcreator.fishawayforge.FishAwayForgeMod;

public class FishAwayForgeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FishAwayForgeMod.MODID);
	public static final RegistryObject<Item> IRON_FISHING_ROD = REGISTRY.register("iron_fishing_rod", () -> new IronFishingRodItem());
	public static final RegistryObject<Item> GOLDEN_FISHING_ROD = REGISTRY.register("golden_fishing_rod", () -> new GoldenFishingRodItem());
	public static final RegistryObject<Item> DIAMOND_FISHING_ROD = REGISTRY.register("diamond_fishing_rod", () -> new DiamondFishingRodItem());
	public static final RegistryObject<Item> NETHERITE_FISHING_ROD = REGISTRY.register("netherite_fishing_rod", () -> new NetheriteFishingRodItem());
	public static final RegistryObject<Item> DRIFTWOOD_SCRAPS = REGISTRY.register("driftwood_scraps", () -> new DriftwoodScrapsItem());
	public static final RegistryObject<Item> PEAR = REGISTRY.register("pear", () -> new PearItem());
	public static final RegistryObject<Item> DRIFTWOOD_BLOCK = block(FishAwayForgeModBlocks.DRIFTWOOD_BLOCK);
	public static final RegistryObject<Item> DRIFTWOOD_LEAVES = block(FishAwayForgeModBlocks.DRIFTWOOD_LEAVES);
	public static final RegistryObject<Item> DIAMOND_CHUNK_STONE = block(FishAwayForgeModBlocks.DIAMOND_CHUNK_STONE);
	public static final RegistryObject<Item> EMERALD_CHUNK_STONE = block(FishAwayForgeModBlocks.EMERALD_CHUNK_STONE);
	public static final RegistryObject<Item> DIAMOND_CHUNK_DEEPSLATE = block(FishAwayForgeModBlocks.DIAMOND_CHUNK_DEEPSLATE);
	public static final RegistryObject<Item> EMERALD_CHUNK_DEEPSLATE = block(FishAwayForgeModBlocks.EMERALD_CHUNK_DEEPSLATE);
	public static final RegistryObject<Item> BASIC_POWER_CABLE = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_E = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_E);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_F = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_F);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_I = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_I);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_L = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_L);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_LC = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_LC);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_LCC = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_LCC);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_LT = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_LT);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_LTC = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_LTC);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_T = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_T);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_TC = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_TC);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_TX = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_TX);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_TXC = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_TXC);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_TXCC = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_TXCC);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_X = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_X);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_XC = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_XC);
	public static final RegistryObject<Item> BASIC_POWER_CABLE_S = block(FishAwayForgeModBlocks.BASIC_POWER_CABLE_S);
	public static final RegistryObject<Item> COPPER_PICKAXE = REGISTRY.register("copper_pickaxe", () -> new CopperPickaxeItem());
	public static final RegistryObject<Item> COPPER_SHOVEL = REGISTRY.register("copper_shovel", () -> new CopperShovelItem());
	public static final RegistryObject<Item> COPPER_HOE = REGISTRY.register("copper_hoe", () -> new CopperHoeItem());
	public static final RegistryObject<Item> COPPER_AXE = REGISTRY.register("copper_axe", () -> new CopperAxeItem());
	public static final RegistryObject<Item> COPPER_SWORD = REGISTRY.register("copper_sword", () -> new CopperSwordItem());
	public static final RegistryObject<Item> COPPER_FISHING_ROD = REGISTRY.register("copper_fishing_rod", () -> new CopperFishingRodItem());
	public static final RegistryObject<Item> HAT_50_HELMET = REGISTRY.register("hat_50_helmet", () -> new Hat50Item.Helmet());
	public static final RegistryObject<Item> HAT_100_HELMET = REGISTRY.register("hat_100_helmet", () -> new Hat100Item.Helmet());
	public static final RegistryObject<Item> OLD_BOOT_1 = REGISTRY.register("old_boot_1", () -> new OldBoot1Item());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
