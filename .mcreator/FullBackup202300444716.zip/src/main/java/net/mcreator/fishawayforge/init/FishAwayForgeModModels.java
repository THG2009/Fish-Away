
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fishawayforge.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.fishawayforge.client.model.Modelhat_50;
import net.mcreator.fishawayforge.client.model.Modelhat_100;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class FishAwayForgeModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelhat_50.LAYER_LOCATION, Modelhat_50::createBodyLayer);
		event.registerLayerDefinition(Modelhat_100.LAYER_LOCATION, Modelhat_100::createBodyLayer);
	}
}
