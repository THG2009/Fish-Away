package net.mcreator.fishawayforge.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.fishawayforge.init.FishAwayForgeModBlocks;

public class BasicPowerCableModelUpdaterMainProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (!world.isClientSide()) {
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE.get())) {
				BasicPowerCableModelUpdaterNProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_E.get())) {
				BasicPowerCableModelUpdaterEProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_I.get())) {
				BasicPowerCableModelUpdaterIProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_L.get())) {
				BasicPowerCableModelUpdaterLProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_LC.get())) {
				BasicPowerCableModelUpdaterLCProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_LCC.get())) {
				BasicPowerCableModelUpdaterLCCProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_LT.get())) {
				BasicPowerCableModelUpdaterLTProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_LTC.get())) {
				BasicPowerCableModelUpdaterLTCProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_T.get())) {
				BasicPowerCableModelUpdaterTProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_TC.get())) {
				BasicPowerCableModelUpdaterTCProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_TX.get())) {
				BasicPowerCableModelUpdaterTXProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_TXC.get())) {
				BasicPowerCableModelUpdaterTXCProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_TXCC.get())) {
				BasicPowerCableModelUpdaterTXCCProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_X.get())) {
				BasicPowerCableModelUpdaterXProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_XC.get())) {
				BasicPowerCableModelUpdaterXCProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_F.get())) {
				BasicPowerCableModelUpdaterFProcedure.execute(world, x, y, z);
			}
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == FishAwayForgeModBlocks.BASIC_POWER_CABLE_S.get())) {
				BasicPowerCableModelUpdaterSProcedure.execute(world, x, y, z);
			}
		}
	}
}
