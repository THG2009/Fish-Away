package net.mcreator.fishawayforge.procedures;

import net.minecraft.world.level.LevelAccessor;

public class BasicPowerCableUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (!world.isClientSide()) {
			BasicPowerCableModelUpdaterMainProcedure.execute(world, x, y, z);
			BasicPowerCableForgeEnergyMainProcedure.execute(world, x, y, z);
		}
	}
}
